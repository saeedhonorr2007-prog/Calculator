پروژه ماشین حساب اندروید (Java)

برای باز کردن:
1. فایل ZIP را استخراج کنید.
2. Android Studio را باز کنید.
3. گزینه Open را بزنید و پوشه CalculatorAndroidProject را انتخاب کنید.
4. صبر کنید Gradle Sync کامل شود.
5. برای ساخت APK از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) استفاده کنید.

نکته: این بسته سورس کامل پروژه است، نه فایل APK کامپایل‌شده.
Android Studio برای Sync و ساخت APK به اینترنت و Android SDK مناسب نیاز دارد.
